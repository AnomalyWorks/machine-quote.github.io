/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visormuestrasbalistica;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.swing.JFrame;

/**
 *
 * @author andob
 */
public final class UtilidadesGenerales {
    //nombres
    //Almacena el registro de muestras
    public static final String SAVE_FILE_NAME="save";
    public static final String SAVE_FOLDER_DATA="data";
    //Almacena las imagenes ligadas a las muestras
    public static final String SAVE_FOLDER_MUESTRAS="muestras";
    //Almacena la correspondecias entre muestras
    public static final String CONFIG_FILE="config";
    //Almacena ultima carpeta visitada para cargar muestras
    public static final String TEMP_FILE="temp";
    
    //Nombres logs
    public static final String LOG_COTEJO="Log_CotejoMuestras";
    public static final String LOG_SIMPLE="Log_VerMuestra";

    //Almacena capturas
    public static final String CAP_FOLDER="capturas";
    public static final String LOG_FOLDER="logs";
    
    //rutas relativas
    public static final String PATH_TEMP_FILE="./"+SAVE_FOLDER_DATA+"/"+TEMP_FILE;
    public static final String PATH_SAVE_FILE="./"+SAVE_FOLDER_DATA+"/"+SAVE_FILE_NAME;
    public static final String PATH_FOLDER_MUESTRAS="./"+SAVE_FOLDER_MUESTRAS;
    public static final String PATH_FOLDER_CAPTURAS="./"+CAP_FOLDER;
    public static final String PATH_FOLDER_LOG="./"+LOG_FOLDER;
  
    //Formato imagenes
    public final static String JPEG = "jpeg";
    public final static String JPG = "jpg";
    public final static String PNG = "png";
    
    //Formato log
    public final static String CARGA_MUESTRA = "se cargó";
    public final static String POSICION_MUESTRA = "se posicionó en las coordenadas";
    public final static String ZOOM_MUESTRA= "se le efectuó una escala de";
    public final static String CAPTURA_MUESTRA= "se efectuó una captura";
    public final static String GIRO_MUESTRA= "se le efectuó un giro de";
    public final static String RED_MUESTRA= "se redimensionó a";
    public final static String VOLT_MUESTRA= "se volteó";
    public final static String VOLT_H="horizontalmente";
    public final static String VOLT_V="verticalmente";
    public final static String GIRO_I="izquierda";
    public final static String GIRO_D="derecha";
    
    public static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        return ext;
    }
    
       //Se crea un archivo
    public static void crearArchivo(ArrayList<String> lineasVolcado, String rutaArchivo) {
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            fichero = new FileWriter(rutaArchivo);
            pw = new PrintWriter(fichero);

            for (int i = 0; i < lineasVolcado.size(); i++)
                pw.println(lineasVolcado.get(i));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           try {
           // Nuevamente aprovechamos el finally para 
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }
    }
    
    //Devuelve un listado de las lineas de un archivo que responden al patrón indicado
    public static ArrayList<String> buscarPatronArchivo(String rutaArchivo, String patronBuscar) {
        File archivo= new File(rutaArchivo);
        Scanner s;
        String linea;
        ArrayList<String> lineasCoincidePatron= new ArrayList();
        String res;
        
        try {
            s= new Scanner(archivo);
            
            while (s.hasNextLine()){
                linea=s.nextLine();
                //Se verifica si la linea coincide con el patron
                res=buscarPatronLinea(linea,patronBuscar);
                
                if(!res.equals("")){
                    lineasCoincidePatron.add(res);
                }
                
                
            }
            
            s.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(UtilidadesGenerales.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        return lineasCoincidePatron;
    }
    
    //Crea un archivo temporal con el arraylist recibido
    public static void crearArchivoTemporal(ArrayList<String> lineasVolcado, String rutaArchivo) {
        FileWriter fichero = null;
        PrintWriter pw = null;
        try
        {
            fichero = new FileWriter(rutaArchivo+"TEMP");
            pw = new PrintWriter(fichero);

            for (int i = 0; i < lineasVolcado.size(); i++)
                pw.println(lineasVolcado.get(i));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           try {
           // Nuevamente aprovechamos el finally para 
           // asegurarnos que se cierra el fichero.
           if (null != fichero)
              fichero.close();
           } catch (Exception e2) {
              e2.printStackTrace();
           }
        }
    }
    
    //Renombra el archivo temporal
    public static boolean eliminarRenombrarArchivoTemporal(String rutaArchivo) {
        File archivoAntiguo= new File(rutaArchivo);
        File archivoTemporal= new File(rutaArchivo+"TEMP");
        
        archivoAntiguo.delete();
        
        return archivoTemporal.renameTo(new File(rutaArchivo));
    }
    
    //Devuelve un substring si se encuentra el patron consulta, de lo contrario retornará uno vacío
    public static String buscarPatronLinea(String linea, String patronBuscar){
        Pattern patron=Pattern.compile(patronBuscar);
        Matcher m=patron.matcher(linea);
        String res="";
        
        if(m.find()){
            res=m.group(1);
        }
            
        return res;
    }

    public static ArrayList<String> limpiarLog(ArrayList<String> log) {
        ArrayList<String> limpio= new ArrayList();
        
        if (!log.isEmpty()){
            limpio.add(log.get(0));
            
            for(int i=1;i<log.size();i++){
                if (!limpio.contains(log.get(i))){
                    limpio.add(log.get(i));
                }
            }
        }
        
        
        return limpio;
    }
    
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = BigDecimal.valueOf(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);

        return bd.doubleValue();
    }
    
    public static BufferedImage obtenerImagen(String ruta){
        File imageFile= new File(ruta);
        BufferedImage img= new BufferedImage(50,50,BufferedImage.TRANSLUCENT);
        
        try {
            img = ImageIO.read(imageFile);
        } catch (IOException ex) {
            Logger.getLogger(UtilidadesGenerales.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return img;
    }
    
    public static void setearIconoFrame(JFrame jf){
        Image im= UtilidadesGenerales.obtenerImagen("./assets/bala_icono.png");
        jf.setIconImage(im);
    }
}
