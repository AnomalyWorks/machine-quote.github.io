/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visormuestrasbalistica;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;

/*
 *  Simple implementation of a Glass Pane that will capture and ignore all
 *  events as well paint the glass pane to give the frame a "disabled" look.
 *
 *  The background color of the glass pane should use a color with an
 *  alpha value to create the disabled look.
 */
public class DisabledGlassPane extends JComponent implements KeyListener
        
{
	
	private JPanel panelOrigen;
        private JPanel panelCentral;
        private JPanel panelIzq;
        private JPanel panelDer;
        private JPanel panelSup;
        private JPanel panelInf;
        private JButton salirModo;
        private JButton limpiarD;
        private JButton capturar;
        private JButton modoDibujoLibre;
        private JButton modoDibujoCuadrado;
        private JButton modoDibujoCirculo;
        private JButton modoDibujoLinea;
        private JButton modoDibujoFlecha;
        private JTextField selColor;
        private JLabel labelSColor;
        private JLabel labelModoDibujo;
        private BufferedImage canvasImage;
        private BufferedImage imagenCuadrado;
        private BufferedImage imagenCirculo;
        private BufferedImage imagenFlecha;
        private BufferedImage imagenLinea;
        private Color colorDibujo;
        private Stroke stroke; 
        private JLabel imageLabel;
        private Color background;
        private Point puntoInicioFigura;

	public DisabledGlassPane(JPanel jp){
		//  Set glass pane properties
                
                this.panelOrigen=jp;
                this.panelCentral= new JPanel();
                this.panelDer= new JPanel();
                this.panelIzq=new JPanel();
                this.panelInf=new JPanel();
                this.panelSup=new JPanel();
                this.salirModo=new JButton("Cerrar");
                this.limpiarD=new JButton("Borrar");
                this.capturar=new JButton("Capturar");
                this.modoDibujoLibre= new JButton("Libre");
                this.modoDibujoCuadrado= new JButton("Cuadrado");
                this.modoDibujoCirculo= new JButton("Circulo");
                this.modoDibujoLinea= new JButton("Linea");
                this.modoDibujoFlecha= new JButton("Flecha");
                this.selColor=new JTextField(" ");
                this.labelSColor=new JLabel("Seleccionar color:");
                this.labelModoDibujo= new JLabel("Seleccionar herramienta:");
                this.colorDibujo= new Color(255,0,0);
                this.stroke= new BasicStroke(3,BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND,1.7f);
                this.imageLabel= new JLabel("");
                
                Color base = UIManager.getColor("inactiveCaptionBorder");
                this.background = new Color(base.getRed(), base.getGreen(), base.getBlue(), 0);
                
                selColor.setEnabled(false);
                selColor.setBackground(colorDibujo);
                
                add(panelCentral);
                add(panelIzq);
                add(panelDer);
                add(panelInf);
                add(panelSup);
                
                setOpaque( false );
                
                Color colorB = new Color(0, 0, 0, 110);

                panelCentral.setOpaque(false);
                panelCentral.setBackground(background);
                
                panelIzq.setOpaque(true);
                panelIzq.setBackground(colorB);
                
                panelDer.setOpaque(true);
                panelDer.setBackground(colorB);
                
                panelSup.setOpaque(true);
                panelSup.setBackground(colorB);
                
                
                panelInf.setOpaque(true);
                panelInf.setBackground(colorB);
                
                modoDibujoLibre.setEnabled(false);
                
                actualizar();
        }

	/*
	 *  The component is transparent but we want to paint the background
	 *  to give it the disabled look.
	 */
	@Override
	protected void paintComponent(Graphics g)
	{
            setBackground( background );
            
            g.setColor( getBackground() );
            g.fillRect(0, 0, getSize().width, getSize().height);
            actualizar();
            
                
	}
        

	/*
	 *  The	background color of the message label will be the same as the
	 *  background of the glass pane without the alpha value
	 */
	@Override
	public void setBackground(Color background)
	{
		super.setBackground( background );


	}
//
//  Implement the KeyListener to consume events
//
	public void keyPressed(KeyEvent e)
	{
		e.consume();
	}

	public void keyTyped(KeyEvent e) {}

	public void keyReleased(KeyEvent e)
	{
		e.consume();
	}

	/*
	 *  Make the glass pane visible and change the cursor to the wait cursor
	 *
	 *  A message can be displayed and it will be centered on the frame.
	 */
	public void activate()
	{
		
                setVisible(true);
                crearGUI();
		requestFocusInWindow();
	}

	/*
	 *  Hide the glass pane and restore the cursor
	 */
	public void desactivate()
	{
		setCursor(null);
		setVisible(false);
	}
        
    public void actualizar(){
            panelCentral.setSize(panelOrigen.getWidth(), panelOrigen.getHeight());
            Point point= new Point(panelOrigen.getX(),panelOrigen.getY());
            panelCentral.setLocation(point);

            int anchoPanelIz=panelCentral.getX();
            int anchoPanelDer=getWidth()-anchoPanelIz-panelCentral.getWidth();
            int altoP=getHeight();
            
            
            Point locPIzq= new Point(0,0);
            Point locPDer= new Point(anchoPanelIz+panelCentral.getWidth(),0);
            Point locPSup= new Point(anchoPanelIz,0);
            Point locPInf= new Point(anchoPanelIz,panelCentral.getY()+panelCentral.getHeight());
            
            panelIzq.setLocation(locPIzq);
            panelIzq.setSize(anchoPanelIz,altoP);
            
            panelDer.setLocation(locPDer);
            panelDer.setSize(anchoPanelDer,altoP);
            
            panelSup.setLocation(locPSup);
            panelSup.setSize(panelCentral.getWidth(),panelCentral.getY());
            
            panelInf.setLocation(locPInf);
            panelInf.setSize(panelCentral.getWidth(),getHeight()-panelCentral.getY()-panelCentral.getHeight());
            
            //Escalar image
            
            if (canvasImage!=null){
                canvasImage=resize(canvasImage,panelCentral.getWidth(),panelCentral.getHeight());

                imageLabel.setIcon(new ImageIcon(canvasImage));
            }
    }

    private void crearGUI() {
                canvasImage= new BufferedImage(panelCentral.getWidth(),panelCentral.getHeight(),BufferedImage.TYPE_INT_ARGB);
                imageLabel.setIcon(new ImageIcon(canvasImage));
                
                GroupLayout layout = new GroupLayout(panelInf);
                layout.setAutoCreateGaps(true);
                layout.setAutoCreateContainerGaps(true);
                
                //Definicion subgrupo
                GroupLayout.SequentialGroup hSubGroup = layout.createSequentialGroup();
                GroupLayout.SequentialGroup vSubGroup = layout.createSequentialGroup();
                
                hSubGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(modoDibujoCuadrado,85,85,85)
                    .addComponent(modoDibujoCirculo,85,85,85)
                );
                
                hSubGroup.addGap(10);
                hSubGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(modoDibujoLinea,85,85,85)
                    .addComponent(modoDibujoFlecha,85,85,85)
                );
                
                
                hSubGroup.addGap(10);
                hSubGroup.addComponent(modoDibujoLibre,85,85,85);
                
                hSubGroup.addGap(30);
                hSubGroup.addComponent(limpiarD);
                
                vSubGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(modoDibujoCuadrado)
                    .addComponent(modoDibujoLinea)
                    .addComponent(modoDibujoLibre)
                    .addComponent(limpiarD)
                );
                
                vSubGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(modoDibujoCirculo)
                    .addComponent(modoDibujoFlecha)
                );
                
                //Definición grupos
                GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();
                GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();
                
                hGroup.addComponent(salirModo,80,80,80);
                
                hGroup.addGap(50);
                hGroup.addComponent(capturar,80,80,80);
                
                hGroup.addGap(50);
                hGroup.addComponent(labelSColor);
                hGroup.addComponent(selColor,25,25,25);
                
                hGroup.addGap(10);
                hGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
                    .addComponent(labelModoDibujo)
                    .addGroup(hSubGroup)
                );
                
                vGroup.addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
                    .addComponent(salirModo)
                    .addComponent(capturar)
                    .addComponent(labelSColor)
                    .addComponent(selColor)
                    .addComponent(labelModoDibujo)
                );
                
                vGroup.addGroup(vSubGroup);
                
                
                layout.setHorizontalGroup(hGroup);
                layout.setVerticalGroup(vGroup);
                
                panelInf.setLayout(layout);
                
                panelCentral.add(imageLabel);
		
                
               aniadirEscuchas();
                
                
    }
    
    public void setearDibujo(BufferedImage img){
        canvasImage=img;
        imageLabel.setIcon(new ImageIcon(img));
    }
    
    public BufferedImage getDibujo(){
        return canvasImage;
    }
    
    public JLabel getImageLabel(){
        return imageLabel;
    }
    
    
    public void aniadirEscuchas(){
                imageLabel.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                        if (!modoDibujoLibre.isEnabled()){
                            draw(e.getPoint());
                        }
                        
                        if (!modoDibujoCuadrado.isEnabled()){
                            puntoInicioFigura= e.getPoint();
                        }
                        
                        if (!modoDibujoCirculo.isEnabled()){
                            puntoInicioFigura= e.getPoint();
                        }
                        
                        if (!modoDibujoLinea.isEnabled()){
                            puntoInicioFigura= e.getPoint();
                        }
                        
                        if (!modoDibujoFlecha.isEnabled()){
                            puntoInicioFigura= e.getPoint();
                        }
                    }
                    
                    public void mouseReleased(MouseEvent e){
                        if (!modoDibujoCuadrado.isEnabled()){
                            canvasImage=imagenCuadrado;
                        }
                        
                        if (!modoDibujoCirculo.isEnabled()){
                            canvasImage=imagenCirculo;
                        }
                        
                        if (!modoDibujoLinea.isEnabled()){
                            canvasImage=dibujarLinea(puntoInicioFigura,e.getPoint(),"simple");
                        }
                        
                        if (!modoDibujoFlecha.isEnabled()){
                            canvasImage=dibujarLinea(puntoInicioFigura,e.getPoint(),"flecha");
                        }
                    }
                });
                
                imageLabel.addMouseMotionListener(new MouseMotionAdapter(){
                    public void mouseDragged(MouseEvent e){
                        if (!modoDibujoLibre.isEnabled()){
                            draw(e.getPoint());
                        }
                        
                        if (!modoDibujoCuadrado.isEnabled()){
                            imagenCuadrado=drawFigura(puntoInicioFigura,e.getPoint(),"cuadrado");
                        }
                        
                        if (!modoDibujoCirculo.isEnabled()){
                            imagenCirculo=drawFigura(puntoInicioFigura,e.getPoint(),"circulo");
                        }
                    }
                });
                
                //  Disable Mouse, Key and Focus events for the glass pane
                
		addMouseListener(new MouseAdapter(){});
		addMouseMotionListener(new MouseMotionAdapter(){});
                
		addKeyListener(this);

		setFocusTraversalKeysEnabled(false);
                
                capturar.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        
                        String estampaTiempo = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
                        //Toolkit.getDefaultToolkit().getScreenSize()
                        try {
                            BufferedImage image = new Robot().createScreenCapture(new Rectangle(panelCentral.getLocationOnScreen().x,panelCentral.getLocationOnScreen().y,panelCentral.getWidth(),panelCentral.getHeight()));
                            try {
                                ImageIO.write(image, "png", new File(UtilidadesGenerales.PATH_FOLDER_CAPTURAS+"/screenshot"+estampaTiempo+".png"));
                            } catch (IOException ex) {
                                Logger.getLogger(DisabledGlassPane.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        } catch (AWTException ex) {
                            Logger.getLogger(DisabledGlassPane.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        
                        JOptionPane.showConfirmDialog(null,"La captura se guardo exitosamente!", "", JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE);
                    }
                });
                
                limpiarD.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        canvasImage= new BufferedImage(panelCentral.getWidth(),panelCentral.getHeight(),BufferedImage.TRANSLUCENT);
                        imageLabel.setIcon(new ImageIcon(canvasImage));
                    }
                });
                
                salirModo.addActionListener(new ActionListener(){
                    public void actionPerformed(ActionEvent e){
                        desactivate();
                    }
                });
                
                selColor.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                        colorDibujo = JColorChooser.showDialog(panelCentral,"Selecciona color",selColor.getBackground());
                        selColor.setBackground(colorDibujo);
                    }
                });
                
                //Control botones modo de dibujo
                modoDibujoLibre.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                       if (modoDibujoLibre.isEnabled()){
                           modoDibujoLibre.setEnabled(false);
                           modoDibujoCuadrado.setEnabled(true);
                           modoDibujoCirculo.setEnabled(true);
                           modoDibujoFlecha.setEnabled(true);
                           modoDibujoLinea.setEnabled(true);
                       }
                    }
                });
                
                modoDibujoCuadrado.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                       if (modoDibujoCuadrado.isEnabled()){
                           modoDibujoLibre.setEnabled(true);
                           modoDibujoCuadrado.setEnabled(false);
                           modoDibujoCirculo.setEnabled(true);
                           modoDibujoFlecha.setEnabled(true);
                           modoDibujoLinea.setEnabled(true);
                       }
                    }
                });
                
                modoDibujoCirculo.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                       if (modoDibujoCirculo.isEnabled()){
                           modoDibujoLibre.setEnabled(true);
                           modoDibujoCuadrado.setEnabled(true);
                           modoDibujoCirculo.setEnabled(false);
                           modoDibujoFlecha.setEnabled(true);
                           modoDibujoLinea.setEnabled(true);
                       }
                    }
                });
                
                modoDibujoLinea.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                       if (modoDibujoFlecha.isEnabled()){
                           modoDibujoLibre.setEnabled(true);
                           modoDibujoCuadrado.setEnabled(true);
                           modoDibujoCirculo.setEnabled(true);
                           modoDibujoFlecha.setEnabled(true);
                           modoDibujoLinea.setEnabled(false);
                       }
                    }
                });
                
                modoDibujoFlecha.addMouseListener(new MouseAdapter(){
                    public void mousePressed(MouseEvent e){
                       if (modoDibujoFlecha.isEnabled()){
                           modoDibujoLibre.setEnabled(true);
                           modoDibujoCuadrado.setEnabled(true);
                           modoDibujoCirculo.setEnabled(true);
                           modoDibujoFlecha.setEnabled(false);
                           modoDibujoLinea.setEnabled(true);
                       }
                    }
                });
    }
    
    public void draw(Point point) {
        Graphics2D g = this.canvasImage.createGraphics();
        //g.setRenderingHints(renderingHints);
        g.setColor(this.colorDibujo);
        g.setStroke(stroke);
        int n = 3;

        g.drawLine(point.x, point.y, point.x+n, point.y+n);
        g.dispose();
        this.imageLabel.repaint();
    }
    
    private BufferedImage dibujarLinea(Point cInicio,Point cFinal, String estilo){
        BufferedImage im= copyImage(this.canvasImage);
        Graphics2D g = im.createGraphics();
        
        g.setColor(this.colorDibujo);
        g.setStroke(stroke);
        
        if (estilo.equals("flecha")){
            drawArrowLine(g,cInicio.x,cInicio.y,cFinal.x,cFinal.y,8,8);
        }
        
        if (estilo.equals("simple")){
            g.drawLine(cInicio.x, cInicio.y, cFinal.x, cFinal.y);
        }
        
        return im;
    }
    
    //Dibuja una flecha con origen y destino, y con ancho y alto de punta flecha
    private void drawArrowLine(Graphics g, int x1, int y1, int x2, int y2, int d, int h) {
        int dx = x2 - x1, dy = y2 - y1;
        double D = Math.sqrt(dx*dx + dy*dy);
        double xm = D - d, xn = xm, ym = h, yn = -h, x;
        double sin = dy / D, cos = dx / D;

        x = xm*cos - ym*sin + x1;
        ym = xm*sin + ym*cos + y1;
        xm = x;

        x = xn*cos - yn*sin + x1;
        yn = xn*sin + yn*cos + y1;
        xn = x;

        int[] xpoints = {x2, (int) xm, (int) xn};
        int[] ypoints = {y2, (int) ym, (int) yn};

        g.drawLine(x1, y1, x2, y2);
        g.fillPolygon(xpoints, ypoints, 3);
    }
    
    public BufferedImage drawFigura(Point start, Point fin, String figura){
        BufferedImage im= copyImage(this.canvasImage);
        Graphics2D g = im.createGraphics();
        
        int ancho= Math.abs(start.x-fin.x);
        int alto= Math.abs(start.y-fin.y);
        
        //Dibuja la figura según las posiciones donde se apretó y movió el mouse
        if ((start.x - fin.x)<0 && (start.y - fin.y)<0 ){
            dibujar(start.x, start.y, ancho, alto, figura, g);
        }
        
        if ((start.x - fin.x)>0 && (start.y - fin.y)>0 ){
            dibujar(start.x-ancho, start.y-alto, ancho, alto, figura, g);
        }
        
        if ((start.x - fin.x)<0 && (start.y - fin.y)>0 ){
            dibujar(start.x, start.y-alto, ancho, alto, figura, g);
        }
        
        if ((start.x - fin.x)>0 && (start.y - fin.y)<0 ){
            dibujar(start.x-ancho, start.y, ancho, alto,figura, g);
        }
        
        g.dispose();
        
        return im;
    }
    
    
    public static BufferedImage resize(BufferedImage img, int newW, int newH) { 
        Image tmp = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
        BufferedImage dimg = new BufferedImage(newW, newH, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = dimg.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
        return dimg;
    } 
    
    public static BufferedImage copyImage(BufferedImage source){
        BufferedImage b = new BufferedImage(source.getWidth(), source.getHeight(), source.getType());
        Graphics g = b.getGraphics();
        g.drawImage(source, 0, 0, null);
        g.dispose();
        return b;
    }

    private void dibujar(int x, int y, int ancho, int alto, String figura, Graphics2D g) {
        g.setColor(this.colorDibujo);
        g.setStroke(stroke);
        
        if (figura.equals("cuadrado")){
            g.drawRect(x, y, ancho, alto);
        }
        
        if (figura.equals("circulo")){
            g.drawOval(x, y, ancho, alto);
        }
    }
}
