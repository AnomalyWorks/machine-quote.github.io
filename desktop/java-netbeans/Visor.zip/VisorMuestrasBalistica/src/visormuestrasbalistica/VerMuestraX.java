/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visormuestrasbalistica;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.JViewport;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.border.MatteBorder;

/**
 *
 * @author andob
 */
public class VerMuestraX extends javax.swing.JFrame {

    private ArrayList<String> listaSave;
    private DefaultComboBoxModel<String> cbm;
    private DefaultComboBoxModel<String> cbm2;
    private boolean bloquear=false;
    private boolean modoDibujo=false;
    private DisabledGlassPane glassPane;
    
    //Datos de la imagen del scrollpane1
    private ArrayList<String> rutasImagenes;
    private int posicionInicial;
    private int posicionActualImagen;
    private boolean terminadoPrecarga=false;
    private Point origin;
    private BufferedImage image;
    private BufferedImage imageRotM1;
    private double scale;
    private double centroViewImagenX;
    private double centroViewImagenY;
    private int gradosM1;
    
    //Datos de la imagen del scrollpane2
    private ArrayList<String> rutasImagenes2;
    private int posicionActualImagen2;
    private Point origin2;
    private BufferedImage image2;
    private BufferedImage imageRotM2;
    private double scale2;
    private boolean muestra2Cargada=false;
    private ArrayList<String> log;
    private double centroViewImagen2X;
    private double centroViewImagen2Y;
    private int gradosM2;
    
    //Bandera para registrar zoom, que se dispara cuando se hace otra cosa
    //Sirve para no tener tantos registros de zoom en el log
    private boolean seHizoZoomEn1=false;
    private boolean seHizoZoomEn2=false;
    
    public VerMuestraX() {
        initComponents();
    }

    public VerMuestraX(int seleccion, boolean simple){
        this.posicionInicial=seleccion;
        this.log= new ArrayList();
        UtilidadesGenerales.setearIconoFrame(this);
        
        initComponents();
        
        inicializarCeroSlider(cajaGradosM1,sliderM1,"1");
        
        //Si se requiere solo el visor uno para una previsualizacion simple
        //Se desactiva los controles y visor de la muestra 2, y se ajusta el tamaño por defecto
        if (simple){
            jScrollPane2.setVisible(false);
            comboMuestra2.setVisible(false);
            labelMuestra2.setVisible(false);
            labelImagenes2.setVisible(false);
            navImgIM2Button.setVisible(false);
            navImgDM2Button.setVisible(false);
            cajaTextoNroImagen2.setVisible(false);
            bloquearButton.setVisible(false);
            voltearVertM2Button.setVisible(false);
            voltearHorizM2Button.setVisible(false);
            rotarImgLabel2.setVisible(false);
            voltearImgLabel2.setVisible(false);
            rotarIzqM2Button.setVisible(false);
            rotarDerM2Button.setVisible(false);
            cajaGradosM2.setVisible(false);
            sliderM2.setVisible(false);
            labelScaleM2.setVisible(false);
            labelPosM2.setVisible(false);
        }
        //setExtendedState(javax.swing.JFrame.MAXIMIZED_BOTH);
        setearListaMuestras();
        rutasImagenes=obtenerRutasImgMuestra(comboMuestra,navImgIM1Button,navImgDM1Button);
        
        try {
            
            image=setearImgMuestra(0,jScrollPane1,cajaTextoNroImagen,imagenMuestra,rutasImagenes);
            imageRotM1=rotarImagenMuestra(0,image);
            scale=escalarImagenViewPort(image.getWidth(),image.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            zoomImg(jScrollPane1,scale,imagenMuestra,image);
            
        } catch (IOException ex) {
            System.out.println("Error al leer imagen");
        }
        
        reiniciarCentroViewImagen("1");
        posicionActualImagen=0;
        
        //Se registra carga muestra del visor 1 en el log
        registrarCargaLog(cbm.getSelectedItem().toString(),"1");
        cargarImagenMuestraLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",image.getWidth(),image.getHeight());
        
        
        terminadoPrecarga=true;
        setFocusable(true);
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        imagenMuestra = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        imagenMuestra2 = new javax.swing.JLabel();
        comboMuestra = new javax.swing.JComboBox<>();
        labelMuestra = new javax.swing.JLabel();
        volverButton = new javax.swing.JButton();
        labelImagenes = new javax.swing.JLabel();
        navImgIM1Button = new javax.swing.JButton();
        cajaTextoNroImagen = new javax.swing.JTextField();
        navImgDM1Button = new javax.swing.JButton();
        comboMuestra2 = new javax.swing.JComboBox<>();
        labelMuestra2 = new javax.swing.JLabel();
        labelImagenes2 = new javax.swing.JLabel();
        navImgIM2Button = new javax.swing.JButton();
        cajaTextoNroImagen2 = new javax.swing.JTextField();
        navImgDM2Button = new javax.swing.JButton();
        bloquearButton = new javax.swing.JButton();
        rotarImgLabel = new javax.swing.JLabel();
        voltearImgLabel = new javax.swing.JLabel();
        rotarIzqM1Button = new javax.swing.JButton();
        rotarDerM1Button = new javax.swing.JButton();
        voltearVertM1Button = new javax.swing.JButton();
        voltearVertM2Button = new javax.swing.JButton();
        rotarImgLabel2 = new javax.swing.JLabel();
        voltearImgLabel2 = new javax.swing.JLabel();
        voltearHorizM1Button = new javax.swing.JButton();
        voltearHorizM2Button = new javax.swing.JButton();
        modoDibujoButton = new javax.swing.JButton();
        guardarLogButton = new javax.swing.JButton();
        cajaGradosM1 = new javax.swing.JTextField();
        sliderM1 = new javax.swing.JSlider();
        rotarIzqM2Button = new javax.swing.JButton();
        rotarDerM2Button = new javax.swing.JButton();
        cajaGradosM2 = new javax.swing.JTextField();
        sliderM2 = new javax.swing.JSlider();
        labelPosM1 = new javax.swing.JLabel();
        labelScaleM1 = new javax.swing.JLabel();
        labelScaleM2 = new javax.swing.JLabel();
        labelPosM2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Visor Muestras");
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                formKeyReleased(evt);
            }
        });

        jPanel1.setFocusable(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 400));
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.LINE_AXIS));

        jScrollPane1.setBackground(java.awt.Color.BLACK);
        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setToolTipText("");
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setFocusable(false);
        jScrollPane1.setOpaque(false);
        jScrollPane1.setPreferredSize(new java.awt.Dimension(400, 400));
        jScrollPane1.setWheelScrollingEnabled(false);

        imagenMuestra.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagenMuestra.setToolTipText("");
        imagenMuestra.setAutoscrolls(true);
        imagenMuestra.setFocusable(false);
        imagenMuestra.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                imagenMuestraMouseDragged(evt);
            }
        });
        imagenMuestra.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                imagenMuestraMouseWheelMoved(evt);
            }
        });
        imagenMuestra.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                imagenMuestraMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                imagenMuestraMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(imagenMuestra);

        jPanel1.add(jScrollPane1);

        jScrollPane2.setBackground(java.awt.Color.BLACK);
        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setToolTipText("");
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);
        jScrollPane2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane2.setOpaque(false);
        jScrollPane2.setPreferredSize(new java.awt.Dimension(400, 400));
        jScrollPane2.setWheelScrollingEnabled(false);

        imagenMuestra2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        imagenMuestra2.setToolTipText("");
        imagenMuestra2.setAutoscrolls(true);
        imagenMuestra2.setFocusable(false);
        imagenMuestra2.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                imagenMuestra2MouseDragged(evt);
            }
        });
        imagenMuestra2.addMouseWheelListener(new java.awt.event.MouseWheelListener() {
            public void mouseWheelMoved(java.awt.event.MouseWheelEvent evt) {
                imagenMuestra2MouseWheelMoved(evt);
            }
        });
        imagenMuestra2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                imagenMuestra2MousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                imagenMuestra2MouseReleased(evt);
            }
        });
        jScrollPane2.setViewportView(imagenMuestra2);

        jPanel1.add(jScrollPane2);

        comboMuestra.setFocusable(false);
        comboMuestra.setMaximumSize(new java.awt.Dimension(31, 25));
        comboMuestra.setMinimumSize(new java.awt.Dimension(31, 25));
        comboMuestra.setPreferredSize(new java.awt.Dimension(31, 25));
        comboMuestra.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboMuestraItemStateChanged(evt);
            }
        });

        labelMuestra.setText("Muestra:");
        labelMuestra.setFocusable(false);

        volverButton.setText("Volver");
        volverButton.setFocusable(false);
        volverButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                volverButtonActionPerformed(evt);
            }
        });

        labelImagenes.setText("Imagenes:");
        labelImagenes.setFocusable(false);

        navImgIM1Button.setText("<");
        navImgIM1Button.setFocusable(false);
        navImgIM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navImgIM1ButtonActionPerformed(evt);
            }
        });

        cajaTextoNroImagen.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cajaTextoNroImagen.setEnabled(false);
        cajaTextoNroImagen.setFocusable(false);
        cajaTextoNroImagen.setOpaque(false);

        navImgDM1Button.setText(">");
        navImgDM1Button.setFocusable(false);
        navImgDM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navImgDM1ButtonActionPerformed(evt);
            }
        });

        comboMuestra2.setFocusable(false);
        comboMuestra2.setMaximumSize(new java.awt.Dimension(31, 25));
        comboMuestra2.setMinimumSize(new java.awt.Dimension(31, 25));
        comboMuestra2.setPreferredSize(new java.awt.Dimension(31, 25));
        comboMuestra2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboMuestra2ItemStateChanged(evt);
            }
        });

        labelMuestra2.setText("Muestra:");
        labelMuestra2.setFocusable(false);

        labelImagenes2.setText("Imagenes:");
        labelImagenes2.setFocusable(false);

        navImgIM2Button.setText("<");
        navImgIM2Button.setEnabled(false);
        navImgIM2Button.setFocusable(false);
        navImgIM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navImgIM2ButtonActionPerformed(evt);
            }
        });

        cajaTextoNroImagen2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cajaTextoNroImagen2.setEnabled(false);
        cajaTextoNroImagen2.setFocusable(false);
        cajaTextoNroImagen2.setOpaque(false);

        navImgDM2Button.setText(">");
        navImgDM2Button.setEnabled(false);
        navImgDM2Button.setFocusable(false);
        navImgDM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                navImgDM2ButtonActionPerformed(evt);
            }
        });

        bloquearButton.setText("Bloquear");
        bloquearButton.setEnabled(false);
        bloquearButton.setFocusable(false);
        bloquearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bloquearButtonActionPerformed(evt);
            }
        });

        rotarImgLabel.setText("Rotar imagen:");

        voltearImgLabel.setText("Voltear imagen:");

        rotarIzqM1Button.setText("<");
        rotarIzqM1Button.setFocusable(false);
        rotarIzqM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rotarIzqM1ButtonActionPerformed(evt);
            }
        });

        rotarDerM1Button.setText(">");
        rotarDerM1Button.setFocusable(false);
        rotarDerM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rotarDerM1ButtonActionPerformed(evt);
            }
        });

        voltearVertM1Button.setText("V");
        voltearVertM1Button.setFocusable(false);
        voltearVertM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltearVertM1ButtonActionPerformed(evt);
            }
        });

        voltearVertM2Button.setText("V");
        voltearVertM2Button.setEnabled(false);
        voltearVertM2Button.setFocusable(false);
        voltearVertM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltearVertM2ButtonActionPerformed(evt);
            }
        });

        rotarImgLabel2.setText("Rotar imagen:");

        voltearImgLabel2.setText("Voltear imagen:");

        voltearHorizM1Button.setText("H");
        voltearHorizM1Button.setFocusable(false);
        voltearHorizM1Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltearHorizM1ButtonActionPerformed(evt);
            }
        });

        voltearHorizM2Button.setText("H");
        voltearHorizM2Button.setEnabled(false);
        voltearHorizM2Button.setFocusable(false);
        voltearHorizM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                voltearHorizM2ButtonActionPerformed(evt);
            }
        });

        modoDibujoButton.setText("Modo Dibujo");
        modoDibujoButton.setFocusable(false);
        modoDibujoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modoDibujoButtonActionPerformed(evt);
            }
        });

        guardarLogButton.setText("Guardar Log");
        guardarLogButton.setFocusable(false);
        guardarLogButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarLogButtonActionPerformed(evt);
            }
        });

        cajaGradosM1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cajaGradosM1.setEnabled(false);
        cajaGradosM1.setFocusable(false);
        cajaGradosM1.setOpaque(false);

        sliderM1.setMaximum(360);
        sliderM1.setMinimum(-360);
        sliderM1.setToolTipText("");
        sliderM1.setValue(0);
        sliderM1.setFocusable(false);
        sliderM1.setMajorTickSpacing(30);
        sliderM1.setPaintTicks(true);
        sliderM1.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliderM1StateChanged(evt);
            }
        });
        sliderM1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sliderM1MouseReleased(evt);
            }
        });

        rotarIzqM2Button.setText("<");
        rotarIzqM2Button.setEnabled(false);
        rotarIzqM2Button.setFocusable(false);
        rotarIzqM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rotarIzqM2ButtonActionPerformed(evt);
            }
        });

        rotarDerM2Button.setText(">");
        rotarDerM2Button.setEnabled(false);
        rotarDerM2Button.setFocusable(false);
        rotarDerM2Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rotarDerM2ButtonActionPerformed(evt);
            }
        });

        cajaGradosM2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        cajaGradosM2.setEnabled(false);
        cajaGradosM2.setFocusable(false);
        cajaGradosM2.setOpaque(false);

        sliderM2.setMaximum(360);
        sliderM2.setMinimum(-360);
        sliderM2.setToolTipText("");
        sliderM2.setValue(0);
        sliderM2.setEnabled(false);
        sliderM2.setFocusable(false);
        sliderM2.setMajorTickSpacing(30);
        sliderM2.setPaintTicks(true);
        sliderM2.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                sliderM2StateChanged(evt);
            }
        });
        sliderM2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                sliderM2MouseReleased(evt);
            }
        });

        labelScaleM2.setText(" ");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(labelPosM1)
                .addGap(10, 10, 10)
                .addComponent(labelScaleM1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(labelScaleM2)
                .addGap(10, 10, 10)
                .addComponent(labelPosM2)
                .addGap(162, 162, 162))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addComponent(volverButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(guardarLogButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(modoDibujoButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(bloquearButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(sliderM1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(cajaGradosM1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rotarIzqM1Button)
                                .addGap(5, 5, 5)
                                .addComponent(rotarDerM1Button)
                                .addGap(18, 18, 18))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(comboMuestra, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(labelImagenes)
                                            .addComponent(cajaTextoNroImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(navImgIM1Button)
                                                .addGap(5, 5, 5)
                                                .addComponent(navImgDM1Button))
                                            .addComponent(labelMuestra)
                                            .addComponent(rotarImgLabel)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(voltearImgLabel)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(voltearHorizM1Button)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(voltearVertM1Button)))))
                                .addGap(15, 15, 15)))
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelMuestra2)
                            .addComponent(comboMuestra2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(labelImagenes2)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(navImgIM2Button)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(navImgDM2Button))
                            .addComponent(cajaTextoNroImagen2, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rotarImgLabel2)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(voltearImgLabel2)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(voltearHorizM2Button)
                                .addGap(5, 5, 5)
                                .addComponent(voltearVertM2Button))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(sliderM2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(cajaGradosM2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(rotarIzqM2Button)
                                    .addGap(5, 5, 5)
                                    .addComponent(rotarDerM2Button)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 3, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addGap(15, 15, 15))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelPosM1)
                    .addComponent(labelScaleM1)
                    .addComponent(labelScaleM2)
                    .addComponent(labelPosM2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(bloquearButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(modoDibujoButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(guardarLogButton)
                            .addComponent(volverButton))
                        .addGap(15, 15, 15))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelMuestra)
                                .addGap(6, 6, 6)
                                .addComponent(comboMuestra, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(labelImagenes)
                                .addGap(8, 8, 8)
                                .addComponent(cajaTextoNroImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(navImgIM1Button)
                                    .addComponent(navImgDM1Button)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(labelMuestra2)
                                .addGap(6, 6, 6)
                                .addComponent(comboMuestra2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(labelImagenes2)
                                .addGap(10, 10, 10)
                                .addComponent(cajaTextoNroImagen2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(6, 6, 6)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(navImgDM2Button)
                                    .addComponent(navImgIM2Button))))
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rotarImgLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(rotarIzqM1Button)
                                    .addComponent(rotarDerM1Button)
                                    .addComponent(cajaGradosM1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(sliderM1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(voltearImgLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(voltearVertM1Button)
                                    .addComponent(voltearHorizM1Button)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rotarImgLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(rotarIzqM2Button)
                                    .addComponent(rotarDerM2Button)
                                    .addComponent(cajaGradosM2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(sliderM2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(14, 14, 14)
                                .addComponent(voltearImgLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(voltearVertM2Button)
                                    .addComponent(voltearHorizM2Button))))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void volverButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_volverButtonActionPerformed
        setVisible(false);
        dispose();
        new Inicio().setVisible(true);
    }//GEN-LAST:event_volverButtonActionPerformed

    private void navImgIM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navImgIM1ButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        int posicion= posicionActualImagen -1;    
        boolean res=resolverPosicionImagen(posicion,rutasImagenes,navImgIM1Button,navImgDM1Button);
        if (res) {
            posicionActualImagen=posicion;
        }
        
        try {
            inicializarCeroSlider(cajaGradosM1,sliderM1,"1");
            
            image=setearImgMuestra(posicionActualImagen,jScrollPane1,cajaTextoNroImagen,imagenMuestra,rutasImagenes);
            imageRotM1=rotarImagenMuestra(0,image);
            scale=escalarImagenViewPort(image.getWidth(),image.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM1.setText("Escala:"+doubleToString2D(scale));
            
            reiniciarCentroViewImagen("1");
            
            zoomImg(jScrollPane1,scale,imagenMuestra,image);
            setearBorde(imagenMuestra,image.getWidth(),image.getHeight(),scale,jScrollPane1);
            
            //Cargas log
            cargarImagenMuestraLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",image.getWidth(),image.getHeight());
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",doubleToString2D(scale));
            registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_navImgIM1ButtonActionPerformed

    private void navImgDM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navImgDM1ButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        int posicion= posicionActualImagen+1;
        boolean res=resolverPosicionImagen(posicion,rutasImagenes,navImgIM1Button,navImgDM1Button);
        if (res) {
            posicionActualImagen=posicion;
        }
        
        try {
            inicializarCeroSlider(cajaGradosM1,sliderM1,"1");
            
            image=setearImgMuestra(posicionActualImagen,jScrollPane1,cajaTextoNroImagen,imagenMuestra,rutasImagenes);
            imageRotM1=rotarImagenMuestra(0,image);
            scale=escalarImagenViewPort(image.getWidth(),image.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM1.setText("Escala:"+doubleToString2D(scale));
            
            reiniciarCentroViewImagen("1");
            
            cargarImagenMuestraLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",image.getWidth(),image.getHeight());
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            
            zoomImg(jScrollPane1,scale,imagenMuestra,image);
            setearBorde(imagenMuestra,image.getWidth(),image.getHeight(),scale,jScrollPane1);
            
            registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",doubleToString2D(scale));
            registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_navImgDM1ButtonActionPerformed

    private void comboMuestraItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboMuestraItemStateChanged
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        //Si se realiza una seleccion en el combo 1
        if(evt.getStateChange()==1 && terminadoPrecarga){ 
            rutasImagenes=obtenerRutasImgMuestra(comboMuestra,navImgIM1Button,navImgDM1Button);
            try {
            inicializarCeroSlider(cajaGradosM1,sliderM1,"1");
            
            image=setearImgMuestra(0,jScrollPane1,cajaTextoNroImagen,imagenMuestra,rutasImagenes);
            imageRotM1=rotarImagenMuestra(0,image);
            scale=escalarImagenViewPort(image.getWidth(),image.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM1.setText("Escala:"+doubleToString2D(scale));
            
            reiniciarCentroViewImagen("1");
            
            //Se registra carga muestra del visor 1 en el log
            registrarCargaLog(cbm.getSelectedItem().toString(),"1");
            
            cargarImagenMuestraLog(cbm.getSelectedItem().toString(),0,"1",image.getWidth(),image.getHeight());
            
            zoomImg(jScrollPane1,scale,imagenMuestra,image);
            
            posicionActualImagen=0;
            
            //Cargas log posicionamiento zoom
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",doubleToString2D(scale));
            registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        
        
    }//GEN-LAST:event_comboMuestraItemStateChanged

    private void imagenMuestraMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestraMouseDragged
        if (!bloquear){
            //Mover la muestra 1
            moverMuestraX("1",evt,false);
        } 
        
        if (bloquear){
            //Mover ambas muestras
            moverMuestraX("1",evt,true);            
        }
    }//GEN-LAST:event_imagenMuestraMouseDragged

    private void imagenMuestraMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestraMousePressed
        origin = new Point(evt.getPoint());    
    }//GEN-LAST:event_imagenMuestraMousePressed
    
    private void imagenMuestraMouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_imagenMuestraMouseWheelMoved
        if (!bloquear){
            //Hace el zoom a la muestra 1
            zoomMuestraX("1",evt,false);
        }
        
        if (bloquear){
            //Hace el zoom a ambas muestras
            zoomMuestraX("1",evt,true);
        }
    }//GEN-LAST:event_imagenMuestraMouseWheelMoved
    
    private void imagenMuestra2MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestra2MouseDragged
        if (muestra2Cargada){
            if (!bloquear){
                //Se mueve la muestra 2
                moverMuestraX("2",evt,false);
            } else {
                //Se mueven ambas muestras
                moverMuestraX("2",evt,true);
            }
        }
    }//GEN-LAST:event_imagenMuestra2MouseDragged

    private void imagenMuestra2MouseWheelMoved(java.awt.event.MouseWheelEvent evt) {//GEN-FIRST:event_imagenMuestra2MouseWheelMoved
        if (muestra2Cargada){
            if (!bloquear){
                //Hace el zoom a la muestra 2
                zoomMuestraX("2",evt,false);
            }

            if (bloquear){
                //Hace el zoom a ambas muestras
                zoomMuestraX("2",evt,true);
            }
        }
    }//GEN-LAST:event_imagenMuestra2MouseWheelMoved

    private void imagenMuestra2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestra2MousePressed
        if(muestra2Cargada){
            origin2 = new Point(evt.getPoint());  
        }
    }//GEN-LAST:event_imagenMuestra2MousePressed

    private void comboMuestra2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboMuestra2ItemStateChanged
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        muestra2Cargada=true;
        bloquearButton.setEnabled(true);
        rotarIzqM2Button.setEnabled(true);
        rotarDerM2Button.setEnabled(true);
        voltearHorizM2Button.setEnabled(true);
        voltearVertM2Button.setEnabled(true);
        sliderM2.setEnabled(true);
        
        //Si se realiza una seleccion en el combo 2
        if(evt.getStateChange()==1){ 
            
            inicializarCeroSlider(cajaGradosM2,sliderM2,"2");

            rutasImagenes2=obtenerRutasImgMuestra(comboMuestra2,navImgIM2Button,navImgDM2Button);
            try {
            image2=setearImgMuestra(0,jScrollPane2,cajaTextoNroImagen2,imagenMuestra2,rutasImagenes2);
            imageRotM2=rotarImagenMuestra(0,image2);
            scale2=escalarImagenViewPort(image2.getWidth(),image2.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
            reiniciarCentroViewImagen("2");
            
            //Se registra carga muestra del visor 2 en el log
            registrarCargaLog(cbm2.getSelectedItem().toString(),"2");
            
            cargarImagenMuestraLog(cbm2.getSelectedItem().toString(),0,"2",image2.getWidth(),image2.getHeight());
            
            zoomImg(jScrollPane2,scale2,imagenMuestra2,image2);
            setearBorde(imagenMuestra2,image2.getWidth(),image2.getHeight(),scale2,jScrollPane2);
            
            posicionActualImagen2=0;
            
            //Cargas log posicionamiento zoom
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            registrarZoomLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",doubleToString2D(scale2));
            registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        
    }//GEN-LAST:event_comboMuestra2ItemStateChanged

    private void navImgIM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navImgIM2ButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        int posicion= posicionActualImagen2 -1;    
        boolean res=resolverPosicionImagen(posicion,rutasImagenes2,navImgIM2Button,navImgDM2Button);
        if (res) {
            posicionActualImagen2=posicion;
        }
        
        try {
            inicializarCeroSlider(cajaGradosM2,sliderM2,"2");
            
            image2=setearImgMuestra(posicionActualImagen2,jScrollPane2,cajaTextoNroImagen2,imagenMuestra2,rutasImagenes2);
            imageRotM2=rotarImagenMuestra(0,image2);
            scale2=escalarImagenViewPort(image2.getWidth(),image2.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
            
            reiniciarCentroViewImagen("2");
            
            cargarImagenMuestraLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",image2.getWidth(),image2.getHeight());
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            
            zoomImg(jScrollPane2,scale2,imagenMuestra2,image2);
            setearBorde(imagenMuestra2,image2.getWidth(),image2.getHeight(),scale2,jScrollPane2);
            
            registrarZoomLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",doubleToString2D(scale2));
            registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_navImgIM2ButtonActionPerformed

    private void navImgDM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_navImgDM2ButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        int posicion= posicionActualImagen2 +1;    
        boolean res=resolverPosicionImagen(posicion,rutasImagenes2,navImgIM2Button,navImgDM2Button);
        if (res) {
            posicionActualImagen2=posicion;
        }
        
        try {
            inicializarCeroSlider(cajaGradosM2,sliderM2,"2");
            
            image2=setearImgMuestra(posicionActualImagen2,jScrollPane2,cajaTextoNroImagen2,imagenMuestra2,rutasImagenes2);
            imageRotM2=rotarImagenMuestra(0,image2);
            scale2=escalarImagenViewPort(image2.getWidth(),image2.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
            labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
            
            reiniciarCentroViewImagen("2");
            
            cargarImagenMuestraLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",image2.getWidth(),image2.getHeight());
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            
            zoomImg(jScrollPane2,scale2,imagenMuestra2,image2);
            setearBorde(imagenMuestra2,image2.getWidth(),image2.getHeight(),scale2,jScrollPane2);
            
            registrarZoomLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",doubleToString2D(scale2));
            registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",0);
            
        } catch (IOException ex) {
            Logger.getLogger(VerMuestraX.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_navImgDM2ButtonActionPerformed

    private void bloquearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bloquearButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        if (bloquear){
            Border border= new LineBorder(Color.GRAY,1);
            jPanel1.setBorder(border);
            bloquearButton.setText("Bloquear");
            bloquear=false;
        }else {
            Border border= new LineBorder(Color.RED,1);
            jPanel1.setBorder(border);
            bloquearButton.setText("Desbloquear");
            bloquear=true;
        }
    }//GEN-LAST:event_bloquearButtonActionPerformed
    
    //Mueve las imagenes por medio de las teclas
    //Muestra1: A-D,W-S ; Muestra 2: Teclas direccionales
    private void formKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyReleased
       if(!bloquear){
           //Se mueve la muestra correspondiente
           moverMuestraXTeclas(evt,false);
       }
       
       if (bloquear){
           //Se mueven ambas muestras
           moverMuestraXTeclas(evt,true);
       }
    }//GEN-LAST:event_formKeyReleased

    //Reajusta las imagenes a los valores de la ventana dinámicamente
    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        
        if (terminadoPrecarga){
            //Se obtiene la rotación
            
            if (!muestra2Cargada){
                    
                    scale=escalarImagenViewPort(imageRotM1.getWidth(),imageRotM1.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
                    labelScaleM1.setText("Escala:"+doubleToString2D(scale));
                    zoomImg(jScrollPane1,scale,imagenMuestra,imageRotM1);
                    setearBorde(imagenMuestra,imageRotM1.getWidth(),imageRotM1.getHeight(),scale,jScrollPane1);
                    
                    reiniciarCentroViewImagen("1");
                    registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
                    registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",doubleToString2D(scale));
                    registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",gradosM1);
                    
            } else {

                    scale=escalarImagenViewPort(imageRotM1.getWidth(),imageRotM1.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
                    scale2=escalarImagenViewPort(imageRotM2.getWidth(),imageRotM2.getHeight(),jPanel1.getWidth()/2,jPanel1.getHeight());
                    labelScaleM1.setText("Escala:"+doubleToString2D(scale));
                    labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
                    
                    zoomImg(jScrollPane1,scale,imagenMuestra,imageRotM1);
                    zoomImg(jScrollPane2,scale2,imagenMuestra2,imageRotM2);
                    setearBorde(imagenMuestra,imageRotM1.getWidth(),imageRotM1.getHeight(),scale,jScrollPane1);
                    setearBorde(imagenMuestra2,imageRotM2.getWidth(),imageRotM2.getHeight(),scale2,jScrollPane2);
                    reiniciarCentroViewImagen("X");
                    
                    registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
                    registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
                    registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",doubleToString2D(scale));
                    registrarZoomLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",doubleToString2D(scale2));
                    registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",gradosM1);
                    registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",gradosM2);
            }
        }
        
        if (modoDibujo){
            if(glassPane!=null){
                glassPane.actualizar();
                glassPane.aniadirEscuchas();
            }
        }
    }//GEN-LAST:event_formComponentResized
    
    private void rotarIzqM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rotarIzqM1ButtonActionPerformed
        int grados= sliderM1.getValue()-1;
        int gradosARotar= Math.abs(grados-gradosM1);
        
        if (!bloquear){
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
        }
        
        if (bloquear){
            int grados2= sliderM2.getValue()-1;
            
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
            
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientación indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
        }
        
        
    }//GEN-LAST:event_rotarIzqM1ButtonActionPerformed

    private void rotarDerM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rotarDerM1ButtonActionPerformed
        int grados= sliderM1.getValue()+1;
        int gradosARotar=Math.abs(grados-gradosM1);
        
        if(!bloquear){
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
        }
        
        if(bloquear){
            int grados2= sliderM2.getValue()+1;
            
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
            
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientación indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
        }
    }//GEN-LAST:event_rotarDerM1ButtonActionPerformed

    private void voltearVertM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltearVertM1ButtonActionPerformed
        if (!bloquear){
            //Voltea horizontalmente la muestra 2
            voltearMuestraX(UtilidadesGenerales.VOLT_V,"1",false);
        }
        
        if (bloquear){
            //Voltea horizontalmente ambas muestras
            voltearMuestraX(UtilidadesGenerales.VOLT_V,"1",true);
        }
    }//GEN-LAST:event_voltearVertM1ButtonActionPerformed

    private void voltearVertM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltearVertM2ButtonActionPerformed
        if (!bloquear){
            //Voltea horizontalmente la muestra 2
            voltearMuestraX(UtilidadesGenerales.VOLT_V,"2",false);
        }
        
        if (bloquear){
            //Voltea horizontalmente ambas muestras
            voltearMuestraX(UtilidadesGenerales.VOLT_V,"2",true);
        }
    }//GEN-LAST:event_voltearVertM2ButtonActionPerformed

    private void voltearHorizM1ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltearHorizM1ButtonActionPerformed
        if (!bloquear){
            //Voltea horizontalmente la muestra 1
            voltearMuestraX(UtilidadesGenerales.VOLT_H,"1",false);
        }
        
        if (bloquear){
            //Voltea horizontalmente ambas muestras
            voltearMuestraX(UtilidadesGenerales.VOLT_H,"1",true);
        }
    }//GEN-LAST:event_voltearHorizM1ButtonActionPerformed

    private void voltearHorizM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_voltearHorizM2ButtonActionPerformed
        if (!bloquear){
            //Voltea horizontalmente la muestra 2
            voltearMuestraX(UtilidadesGenerales.VOLT_H,"2",false);
        }
        
        if (bloquear){
            //Voltea horizontalmente ambas muestras
            voltearMuestraX(UtilidadesGenerales.VOLT_H,"2",true);
        }
    }//GEN-LAST:event_voltearHorizM2ButtonActionPerformed

    private void modoDibujoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modoDibujoButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        modoDibujo=true;
        glassPane = new DisabledGlassPane(jPanel1);
        setGlassPane(glassPane);
        glassPane.activate();
        
    }//GEN-LAST:event_modoDibujoButtonActionPerformed

    private void guardarLogButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarLogButtonActionPerformed
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        ArrayList<String> logLimpio= log;//UtilidadesGenerales.limpiarLog(log);
        String estampaTiempo = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
        String nombre= UtilidadesGenerales.LOG_COTEJO+"_"+estampaTiempo+".txt";
        String ruta=UtilidadesGenerales.PATH_FOLDER_LOG+"/"+nombre;
                
        UtilidadesGenerales.crearArchivo(logLimpio, ruta);
        
        JOptionPane.showConfirmDialog(null,"El log se guardo exitosamente!", "", JOptionPane.DEFAULT_OPTION,JOptionPane.INFORMATION_MESSAGE);
        
    }//GEN-LAST:event_guardarLogButtonActionPerformed

    private void imagenMuestraMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestraMouseReleased
        if (!bloquear){
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
        }
        
        if (bloquear){
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
        }
        
    }//GEN-LAST:event_imagenMuestraMouseReleased

    private void imagenMuestra2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_imagenMuestra2MouseReleased
        if(muestra2Cargada){
            if (!bloquear){
                registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            }
            
            if (bloquear){
                registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
                registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            }
        }
    }//GEN-LAST:event_imagenMuestra2MouseReleased

    private void sliderM1StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliderM1StateChanged
        cajaGradosM1.setText(sliderM1.getValue()+"°");
    }//GEN-LAST:event_sliderM1StateChanged

    private void sliderM1MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sliderM1MouseReleased
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        int grados= sliderM1.getValue();
        int gradosARotar=Math.abs(grados-gradosM1);
        String orientacion=obtStringOrient(grados,gradosM1);
        
        if (!bloquear){
            //Rota la muestra 1 con la orientacion indicada
            rotarMuestraX(grados,"1",orientacion,gradosARotar);
        }
        
        if(bloquear){
            //Rota la muestra 1 y 2 con la orientacion indicada
            int grados2= sliderM2.getValue()+grados-gradosM1;
            rotarMuestraX(grados,"1",orientacion,gradosARotar);
            rotarMuestraX(grados2,"2",orientacion,gradosARotar);
        }
        
    }//GEN-LAST:event_sliderM1MouseReleased

    private void rotarIzqM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rotarIzqM2ButtonActionPerformed
        int grados2= sliderM2.getValue()-1;
        int gradosARotar=Math.abs(grados2-gradosM2);
        
        if (!bloquear){
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientacion indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
        }
        
        if(bloquear){
            int grados= sliderM1.getValue()-1;
            
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
            
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientación indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_I,gradosARotar);
            }
        }
        
    }//GEN-LAST:event_rotarIzqM2ButtonActionPerformed

    private void rotarDerM2ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rotarDerM2ButtonActionPerformed
        int grados2= sliderM2.getValue()+1;
        int gradosARotar=Math.abs(grados2-gradosM2);
        
        if (!bloquear){
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientación indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
        }
        
        if(bloquear){
            int grados= sliderM1.getValue()+1;
            
            if (grados>=-360 && grados<=360){
                //Rota la muestra 1 con la orientación indicada
                rotarMuestraX(grados,"1",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
            
            if (grados2>=-360 && grados2<=360){
                //Rota la muestra 2 con la orientación indicada
                rotarMuestraX(grados2,"2",UtilidadesGenerales.GIRO_D,gradosARotar);
            }
        }
    }//GEN-LAST:event_rotarDerM2ButtonActionPerformed

    private void sliderM2StateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_sliderM2StateChanged
        cajaGradosM2.setText(sliderM2.getValue()+"°");
    }//GEN-LAST:event_sliderM2StateChanged

    private void sliderM2MouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sliderM2MouseReleased
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        if (muestra2Cargada){
            int grados2= sliderM2.getValue();
            int gradosARotar= Math.abs(grados2-gradosM2);
            String orientacion=obtStringOrient(grados2,gradosM2);
            
            if (!bloquear){
                rotarMuestraX(grados2,"2",orientacion,gradosARotar);
            }
            
            if (bloquear){
                //Rota la muestra 1 y 2 con la orientacion indicada
                int grados= sliderM1.getValue()+grados2-gradosM2;
                rotarMuestraX(grados,"1",orientacion,gradosARotar);
                rotarMuestraX(grados2,"2",orientacion,gradosARotar);
            }
        }    
    }//GEN-LAST:event_sliderM2MouseReleased

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        setVisible(false);
        dispose();
        new Inicio().setVisible(true);
    }//GEN-LAST:event_formWindowClosing
    
    //Obtiene la imagen rotada a los grados pasados por parámetro
    private BufferedImage rotarImagenMuestra(int angulo, BufferedImage img){
        double rads = Math.toRadians(angulo);
        double sin = Math.abs(Math.sin(rads));
        double cos = Math.abs(Math.cos(rads));

        int w = (int) Math.floor((img.getWidth() * cos) + (img.getHeight() * sin));
        int h = (int) Math.floor((img.getHeight() * cos) + (img.getWidth() * sin));
        
        
        BufferedImage rotatedImage = new BufferedImage(w, h, img.getType());
        AffineTransform at = new AffineTransform();
        at.translate(w / 2, h / 2);
        at.rotate(rads,0, 0);
        at.translate(-img.getWidth() / 2, -img.getHeight() / 2);
        AffineTransformOp rotateOp = new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
        rotateOp.filter(img,rotatedImage);
        
        return rotatedImage;
        
    }
    
    //Obtiene la imagen volteada en el sentido pasado por parámetro
    private BufferedImage voltearMuestra(String sentido,BufferedImage img){
        int t1=1;
        int t2=1;
        int z1=0;
        int z2=0;
        
        if (sentido.equals(UtilidadesGenerales.VOLT_H)){
            t1=-1;
            z1=-img.getWidth(null);
        }
         
        if (sentido.equals(UtilidadesGenerales.VOLT_V)){
            t2=-1;
            z2=-img.getHeight(null);
        }
        
        AffineTransform at=AffineTransform.getScaleInstance(t1, t2);
        at.translate(z1, z2);
        AffineTransformOp op= new AffineTransformOp(at,AffineTransformOp.TYPE_NEAREST_NEIGHBOR); 
        BufferedImage flipImage= op.filter(img,null);
        
        return flipImage;
    }
    
    //Obtiene la lista de imagenes correspondiente a la muestra seleccionada
    private ArrayList<String> obtenerRutasImgMuestra(JComboBox jCBox,JButton ant,JButton sig){
        String[] partes=listaSave.get(jCBox.getSelectedIndex()).split(",");
        String rutaImagenes=partes[0];
        File carpetaMuestra= new File(rutaImagenes);
        String[] imagenesCarpeta= carpetaMuestra.list();
        ArrayList<String> rutasImgs= new ArrayList();
        
        for (int i=0;i<imagenesCarpeta.length;i++){
            
            rutasImgs.add(rutaImagenes+"/"+imagenesCarpeta[i]);
        }
        
        ant.setEnabled(false);
        sig.setEnabled(true);
        
        
        if (rutasImgs.size()<=1){
            sig.setEnabled(false);
        }
        
        return rutasImgs;
    }
    
    //Setea el nombre de la imagen de la muestra en la caja de texto y tambien la imagen
    //Proporciona la imagen que se tendrá como base para realizar las modificaciones
    //Es el método que se ejecuta inicialmente a la hora de cargar la imagen
    private BufferedImage setearImgMuestra(int pos, JScrollPane jSC, JTextField cTextoImg,JLabel cImg, ArrayList<String> rImgs) throws IOException{
        
        File imagenActual= new File(rImgs.get(pos));
        cTextoImg.setText(UtilidadesGenerales.buscarPatronLinea(imagenActual.getName(), "(.*)\\..*"));
        
        File imageFile = new File(rImgs.get(pos));
        BufferedImage img = ImageIO.read(imageFile);

        setImage(img,cImg,jSC);
                
        return img;
    
    }
    
    //Hace zoom out de la imagen escalandola y cargandola al visor correspondiente
    private void zoomImg(JScrollPane jSC, double scl, JLabel cImg, BufferedImage img) {
        setImage(getScaledImage(scl , img),cImg,jSC);

        jSC.revalidate();
        jSC.repaint();
    }
    
    
    //Retorna una imagen escalada al valor pasado por parámetro
    private BufferedImage getScaledImage(double scale, BufferedImage img) {  
        
        int w = (int)(scale*img.getWidth());  
        int h = (int)(scale*img.getHeight());  
        
        BufferedImage bi = new BufferedImage(w, h, img.getType());  
        Graphics2D g2 = bi.createGraphics();  
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BICUBIC);  
        AffineTransform at = AffineTransform.getScaleInstance(scale, scale);  
        g2.drawRenderedImage(img, at);  
        g2.dispose();  
        return bi;  
    }
    
    //Carga la imagen al jlabel
    private void setImage(Image img, JLabel cImg, JScrollPane jSC){
        cImg.setIcon(new ImageIcon(img));

        //ubica el scrollpane centrado y espera a que carge la imagenes
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                
                Rectangle bounds = jSC.getViewport().getViewRect();
                Dimension size = jSC.getViewport().getViewSize();
                
                
                int x = (size.width - bounds.width) / 2;
                int y = (size.height - bounds.height) / 2;
                
                jSC.getViewport().setViewPosition(new Point(x,y));
                
        
        }
        });
    }
    
    //Obtiene la lista de balas disponibles para setear en los combo box
    private void setearListaMuestras(){
        listaSave= UtilidadesGenerales.buscarPatronArchivo(UtilidadesGenerales.PATH_SAVE_FILE,"(.*)");
        cbm=new DefaultComboBoxModel();
        cbm2=new DefaultComboBoxModel();
        String lineaSaveNombre;
        
        cbm2.setSelectedItem("");
        
        for(int i=0;i<listaSave.size();i++){
           String[] partes= listaSave.get(i).split(",");
           lineaSaveNombre=UtilidadesGenerales.buscarPatronLinea(partes[0], ".\\/.*/(.*)_.*-.*-.*_.*-.*-.*");
           cbm.addElement(lineaSaveNombre);
           cbm2.addElement(lineaSaveNombre);
        }
        
        
        comboMuestra.setModel(cbm);
        comboMuestra2.setModel(cbm2);
        comboMuestra.setSelectedIndex(posicionInicial);
        
    }
    
    //Resuelve la posición de la imagen que se previsualiza y activa e inactiva los botones según corresponda
    private boolean resolverPosicionImagen(int pos,ArrayList<String> rImgs, JButton ant,JButton sig){
        boolean res=false;
        
        if (pos>0 && pos<rImgs.size()-1){
            res=true;
            ant.setEnabled(true);
            sig.setEnabled(true);
        }
        
        if (pos>0 && pos==rImgs.size()-1){
            res=true;
            ant.setEnabled(true);
            sig.setEnabled(false);
        }
        
        if (pos==0 && pos<rImgs.size()-1){
            res=true;
            ant.setEnabled(false);
            sig.setEnabled(true);
        }
        
        return res;
    }
    
    //Retorna la escala que debe tener la imagen para entrar al viewport
    private double escalarImagenViewPort(int widthImg, int heightImg, int widthVw, int heightVw) {
        double testAlto=(double) heightImg/heightVw;
        double testAncho=(double) widthImg/widthVw;
        double valor=1;
        
        if (testAlto>testAncho){
            valor=testAlto;
        }else{
            valor=testAncho;
        }
        
        double res = (double) 1/valor;
        
        return res;
    }
    
    //Reinicia el slider a 0
    private void inicializarCeroSlider(JTextField cajaGrados, JSlider slider, String muestra) {
        cajaGrados.setText("0°");
        slider.setValue(0);
        
        if (muestra.equals("1")){
            gradosM1=0;
        }
        
        if (muestra.equals("2")){
            gradosM2=0;
        }
    }
    
    //Efectua las rotaciones 1:para la muestra 1, 2:para la muestra 2, 0:para ambas muestras
    private void rotarMuestraX(int grados, String muestra, String orientacion, int incremento) {
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        if(muestra.equals("1") || muestra.equals("0")){
            imageRotM1=rotarImagenMuestra(grados,image);
            
            //Se vuelve a establecer la escala
            zoomImg(jScrollPane1,scale,imagenMuestra,imageRotM1);
            reiniciarCentroViewImagen("1");
            setearBorde(imagenMuestra,imageRotM1.getWidth(),imageRotM1.getHeight(),scale,jScrollPane1);
            
            //Carga log posicionamiento en 0 y rotacion
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarRotarImMuestraLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",orientacion,incremento);
            registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",grados);
            //Ya que la imagen sufre una redimención producto de la rotación se registra este cambio
            registrarRedimension(cbm.getSelectedItem().toString(),posicionActualImagen,"1",imageRotM1.getWidth(),imageRotM1.getHeight());
            sliderM1.setValue(grados);
            gradosM1=grados;
        }
        
        if(muestra.equals("2") || muestra.equals("0")){
            imageRotM2=rotarImagenMuestra(grados,image2);

            zoomImg(jScrollPane2,scale2,imagenMuestra2,imageRotM2);
            reiniciarCentroViewImagen("2");
            setearBorde(imagenMuestra2,imageRotM2.getWidth(),imageRotM2.getHeight(),scale2,jScrollPane2);
            
            //Carga log posicionamiento en 0 y rotacion
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            registrarRotarImMuestraLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",orientacion,incremento);
            registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",grados);
            //Ya que la imagen sufre una redimención producto de la rotación se registra este cambio
            registrarRedimension(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",imageRotM2.getWidth(),imageRotM2.getHeight());
            sliderM2.setValue(grados);
            gradosM2=grados;
        }
        
        
    }

    //Obtiene la orientación cuando se rota la imagen con el slider
    private String obtStringOrient(int valorActual, int valorAnterior) {
        int or= valorActual - valorAnterior;
        String res="";
        
        if (or<0){
            res=UtilidadesGenerales.GIRO_I;
        }
        
        if (or>0){
            res=UtilidadesGenerales.GIRO_D;
        }
        
        return res;
    }
    
    //Mueve la muestra pasada por parámetro
    private void moverMuestraX(String muestra, java.awt.event.MouseEvent evt, Boolean bloqueo){
        int deltaX = 0;
        int deltaY = 0;
        
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        if (muestra.equals("1")){
            deltaX=origin.x - evt.getX();
            deltaY=origin.y - evt.getY();
        }
        
        if (muestra.equals("2")){
            deltaX=origin2.x - evt.getX();
            deltaY=origin2.y - evt.getY();
        }
        
        if (muestra.equals("1") || bloqueo){
            JViewport viewPort = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, imagenMuestra);
            if (viewPort != null) {
                Rectangle view = viewPort.getViewRect();
                view.x += deltaX;
                view.y += deltaY;

                imagenMuestra.scrollRectToVisible(view);

                  //Se calcula el centro del view con respecto a la imagen
                calcularCoordCVI("1", deltaX, deltaY,imageRotM1.getWidth(),imageRotM1.getHeight());
                Point pos=obtenerCoordCVI("1");
                labelPosM1.setText("("+pos.x+","+pos.y+")");
            }
        }
        
        if (muestra.equals("2") || bloqueo){
            JViewport viewPort = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, imagenMuestra2);
            if (viewPort != null) {

                Rectangle view = viewPort.getViewRect();
                view.x += deltaX;
                view.y += deltaY;

                imagenMuestra2.scrollRectToVisible(view);

                //Se calcula el centro del view con respecto a la imagen
                calcularCoordCVI("2", deltaX, deltaY,imageRotM2.getWidth(),imageRotM2.getHeight());
                Point pos=obtenerCoordCVI("2");
                labelPosM2.setText("("+pos.x+","+pos.y+")");
            }
        }
    }
    
    //Hace el zoom correspondiente a la muestra pasada por parámetro
    private void zoomMuestraX(String muestra, java.awt.event.MouseWheelEvent evt, boolean bloqueo){
        
        if (muestra.equals("1") || bloqueo) {
            //Toma el angulo de rotacion de la imagen

            seHizoZoomEn1=true;
            if (evt.getWheelRotation()<0){
            //ZoomIN
                scale = scale + 0.01;
                labelScaleM1.setText("Escala:"+doubleToString2D(scale));
                zoomImg(jScrollPane1,scale,imagenMuestra,imageRotM1);
                setearBorde(imagenMuestra,imageRotM1.getWidth(),imageRotM1.getHeight(),scale,jScrollPane1);
            }

            if(evt.getWheelRotation()>0 && scale>0){
            //ZoomOUT
                scale = scale - 0.01;
                labelScaleM1.setText("Escala:"+doubleToString2D(scale));
                zoomImg(jScrollPane1,scale,imagenMuestra,imageRotM1);
                setearBorde(imagenMuestra,imageRotM1.getWidth(),imageRotM1.getHeight(),scale,jScrollPane1);
            }
        }
        
        if (muestra.equals("2") || bloqueo){
            //Toma el angulo de rotacion de la imagen
            
            seHizoZoomEn2=true;
                if (evt.getWheelRotation()<0){
                //ZoomIN
                    scale2 = scale2 + 0.01;
                    labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
                    zoomImg(jScrollPane2,scale2,imagenMuestra2,imageRotM2);
                    setearBorde(imagenMuestra2,imageRotM2.getWidth(),imageRotM2.getHeight(),scale2,jScrollPane2);
                }

                if(evt.getWheelRotation()>0 && scale>0){
                //ZoomOUT
                    scale2 = scale2 - 0.01;
                    labelScaleM2.setText("Escala:"+doubleToString2D(scale2));
                    zoomImg(jScrollPane2,scale2,imagenMuestra2,imageRotM2);
                    setearBorde(imagenMuestra2,imageRotM2.getWidth(),imageRotM2.getHeight(),scale2,jScrollPane2);
                }
        }
    }
    
    //Metodo auxiliar para registrar el zoom en el log, solo cuando se haga otra acción distinta al zoom
    //De esa forma se ahorra registros de log
    private void registrarZoom(){
        if (seHizoZoomEn1){
            reiniciarCentroViewImagen("1");
            String sc1=doubleToString2D(scale);
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarZoomLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",sc1);
            seHizoZoomEn1=false;
        }
        
        if (seHizoZoomEn2){
            reiniciarCentroViewImagen("2");
            String sc2=doubleToString2D(scale);
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            registrarZoomLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",sc2);
            seHizoZoomEn2=false;
        }
    }
    
    //Obtiene el double pasado por paramentro y devuelve un string del double con 2 decimales
    private String doubleToString2D(double d){
        DecimalFormat format = new DecimalFormat("#.##");

        return ""+format.format(d);
    }
    
    //Efectua los movimientos de las muestras a traves de las teclas
    private void moverMuestraXTeclas(java.awt.event.KeyEvent evt, boolean bloqueo){
        int key=evt.getKeyCode();
        JViewport viewPort = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, imagenMuestra);
        JViewport viewPort2 = (JViewport) SwingUtilities.getAncestorOfClass(JViewport.class, imagenMuestra2);
        Rectangle view = viewPort.getViewRect();
        Rectangle view2 = viewPort2.getViewRect();
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
           //Controles por tecla muestra 1
           if (key==KeyEvent.VK_A || (bloqueo && key==KeyEvent.VK_LEFT)){
                view.x += 1;
                //Se calcula el centro del view con respecto a la imagen
                calcularCoordCVI("1", 1, 0,imageRotM1.getWidth(),imageRotM1.getHeight());
                registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
           }
           if (key==KeyEvent.VK_D || (bloqueo && key==KeyEvent.VK_RIGHT)){
                view.x += -1;
                calcularCoordCVI("1", -1, 0,imageRotM1.getWidth(),imageRotM1.getHeight());
                registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
           }       
           if (key==KeyEvent.VK_W || (bloqueo && key==KeyEvent.VK_UP)){
                view.y += 1;
                calcularCoordCVI("1", 0, 1,imageRotM1.getWidth(),imageRotM1.getHeight());
                registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
           }
           if (key==KeyEvent.VK_S || (bloqueo && key==KeyEvent.VK_DOWN)){
                view.y += -1;
                calcularCoordCVI("1", 0, -1,imageRotM1.getWidth(),imageRotM1.getHeight());
                registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
           }
               
            //Controles por tecla muestra 2
            if (muestra2Cargada){
               if (key==KeyEvent.VK_LEFT || (bloqueo && key==KeyEvent.VK_A)){
                    view2.x += 1;
                    calcularCoordCVI("2", 1, 0,imageRotM2.getWidth(),imageRotM2.getHeight());
                    registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
               }
               if (key==KeyEvent.VK_RIGHT || (bloqueo && key==KeyEvent.VK_D)){
                    view2.x += -1;
                    calcularCoordCVI("2", -1, 0,imageRotM2.getWidth(),imageRotM2.getHeight());
                    registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
               }       
               if (key==KeyEvent.VK_UP || (bloqueo && key==KeyEvent.VK_W)){
                    view2.y += 1;
                    calcularCoordCVI("2", 0, 1,imageRotM2.getWidth(),imageRotM2.getHeight());
                    registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
               }
               if (key==KeyEvent.VK_DOWN || (bloqueo && key==KeyEvent.VK_S)){
                    view2.y += -1;
                    calcularCoordCVI("2", 0, -1,imageRotM2.getWidth(),imageRotM2.getHeight());
                    registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
               }
            }
            
       imagenMuestra.scrollRectToVisible(view);
       imagenMuestra2.scrollRectToVisible(view2);
    }
    
    private void voltearMuestraX(String orientacion, String muestra, boolean bloqueo){
        //Verifica se hizo zoom previamente para registrarlo
        registrarZoom();
        
        if(muestra.equals("1") || bloqueo){
            BufferedImage im= rotarImagenMuestra(gradosM1,image);
            im=voltearMuestra(orientacion,im);
            //Se guarda el estado de la imagen para que al rotar recuerde los volteos
            image=voltearMuestra(orientacion,image);
            
            zoomImg(jScrollPane1,scale,imagenMuestra,im);
            
            reiniciarCentroViewImagen("1");
            registrarPosicionLog(obtenerCoordCVI("1"),cbm.getSelectedItem().toString(),posicionActualImagen,"1");
            registrarVoltearImMuestraLog(cbm.getSelectedItem().toString(),posicionActualImagen,"1",orientacion);
            
            //Si se hace un volteo horizontal y el grado no es 0 hay que invertir los grados de rotación
            if (gradosM1!=0 && orientacion.equals(UtilidadesGenerales.VOLT_H)){
                sliderM1.setValue(-gradosM1);
                gradosM1=-gradosM1;
                registrarGradoRotacion(cbm.getSelectedItem().toString(),posicionActualImagen,"1",gradosM1);
            }
        }
        
        if(muestra.equals("2") || bloqueo){
            BufferedImage im2= rotarImagenMuestra(gradosM2,image2);
            im2=voltearMuestra(orientacion,im2);
            //Se guarda el estado de la imagen para que al rotar recuerde los volteos
            image2=voltearMuestra(orientacion,image2);

            zoomImg(jScrollPane2,scale2,imagenMuestra2,im2);

            reiniciarCentroViewImagen("2");
            registrarPosicionLog(obtenerCoordCVI("2"),cbm2.getSelectedItem().toString(),posicionActualImagen2,"2");
            registrarVoltearImMuestraLog(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",orientacion);
            
            //Si se hace un volteo horizontal y el grado no es 0 hay que invertir los grados de rotación
            if (gradosM2!=0 && orientacion.equals(UtilidadesGenerales.VOLT_H)){
                sliderM2.setValue(-gradosM2);
                gradosM2=-gradosM2;
                registrarGradoRotacion(cbm2.getSelectedItem().toString(),posicionActualImagen2,"2",gradosM2);
            }
            
        }
    }
    
    private void reiniciarCentroViewImagen(String muestra){
        if (muestra.equals("1") || muestra.equals("X")){
            centroViewImagenX= 0;
            centroViewImagenY= 0;
            labelPosM1.setText("(0,0)");
        }
        
        if (muestra.equals("2") || muestra.equals("X")){
            centroViewImagen2X= 0;
            centroViewImagen2Y= 0;
            labelPosM2.setText("(0,0)");
        }
    }
    
    private Point obtenerCoordCVI(String muestra){
        Point res= new Point(0,0);
        if (muestra.equals("1")){
            res.x= (int) Math.round(centroViewImagenX);
            res.y= (int) Math.round(centroViewImagenY);
        }
        
        if (muestra.equals("2")){
            res.x= (int) Math.round(centroViewImagen2X);
            res.y= (int) Math.round(centroViewImagen2Y);
        }
        
        return res;
    }
    
    //Realiza los cálculos de las coordenadas que van a registrarse luego en el log
    //Pendiente:
    //Transformar esto en además una función que retorne el calculo del centroview para ahorrar código
    private void calcularCoordCVI(String muestra,int deltaX, int deltaY, int anchoImg, int altoImg){
        if (muestra.equals("1")){
            double totalX=centroViewImagenX+ ((1/scale)*deltaX);
            double totalY=centroViewImagenY- ((1/scale)*deltaY);
            //Toma el incremento de X siempre y cuando esté dentro de los límites de X de la imagen
            //Si la imagen tiene un ancho de 800, el rango que podrá tomar centroView será de [-400,400]
            if(totalX>= -(anchoImg/2) && totalX<= (anchoImg/2) ){
                centroViewImagenX=totalX;
            } else {
                //Cuando el delta es grande no permite que se acumule, quedando una carga incompleta de la coord
                if (centroViewImagenX<0 && centroViewImagenX!=-(anchoImg/2)){
                    centroViewImagenX= -(anchoImg/2);
                }
                
                if (centroViewImagenX>0 && centroViewImagenX!= (anchoImg/2)){
                    centroViewImagenX= (anchoImg/2);
                }
            }
            
            //Toma el incremento de Y siempre y cuando esté dentro de los límites de Y de la imagen
            if(totalY>= -(altoImg/2) && totalY<= (altoImg/2) ){
                centroViewImagenY=totalY;
            } else {
                //Cuando el delta es grande no permite que se acumule, quedando una carga incompleta de la coord
                if (centroViewImagenY<0 && centroViewImagenY!=-(altoImg/2)){
                    centroViewImagenY= -(altoImg/2);
                }
                
                if (centroViewImagenY>0 && centroViewImagenY!= (altoImg/2)){
                    centroViewImagenY= (altoImg/2);
                }
            }
        }
        
        if (muestra.equals("2")){
            double totalX=centroViewImagen2X+ ((1/scale2)*deltaX);
            double totalY=centroViewImagen2Y- ((1/scale2)*deltaY);
            //Toma el incremento de X siempre y cuando esté dentro de los límites de X de la imagen
            //Si la imagen tiene un ancho de 800, el rango que podrá tomar centroView será de [-400,400]
            if(totalX>= -(anchoImg/2) && totalX<= (anchoImg/2) ){
                centroViewImagen2X=totalX;
            } else {
                //Cuando el delta es grande no permite que se acumule, quedando una carga incompleta de la coord
                if (centroViewImagen2X<0 && centroViewImagen2X!=-(anchoImg/2)){
                    centroViewImagen2X= -(anchoImg/2);
                }
                
                if (centroViewImagen2X>0 && centroViewImagen2X!= (anchoImg/2)){
                    centroViewImagen2X= (anchoImg/2);
                }
            }
            
            //Toma el incremento de Y siempre y cuando esté dentro de los límites de Y de la imagen
            if(totalY>= -(altoImg/2) && totalY<= (altoImg/2) ){
                centroViewImagen2Y=totalY;
            } else {
                //Cuando el delta es grande no permite que se acumule, quedando una carga incompleta de la coord
                if (centroViewImagen2Y<0 && centroViewImagen2Y!=-(altoImg/2)){
                    centroViewImagen2Y= -(altoImg/2);
                }
                
                if (centroViewImagen2Y>0 && centroViewImagen2Y!= (altoImg/2)){
                    centroViewImagen2Y= (altoImg/2);
                }
            }
        }
    }
    
    //Borde de color que sirve de fondo y para manipular el dragg con cierto limite
    //incrementar el grosor del borde para mayor libertad
    private void setearBorde(JLabel cImg, int ancho, int alto, double sc, JScrollPane jSC){
        double al;
        double an;
        if ((alto*sc)<jSC.getHeight()){
            al=(alto/2)*sc + (jSC.getHeight()-(alto*sc))*0.5;
        }else {
            //está mal
            al=jSC.getWidth()/2;
        }
        
        if ((ancho*sc)<jSC.getWidth()){
            an=(ancho/2)*sc + (jSC.getWidth()-(ancho*sc))*0.5;
        }else{
            //está mal
            an=jSC.getWidth()/2;
        }
        
        int w= (int) Math.round(an);
        int h= (int) Math.round(al);
                
        cImg.setBorder(new MatteBorder(h, w, h, w, Color.black));
    }
    
    /**
     * Cargas en el log
     */
        
    private void registrarPosicionLog(Point punto, String nombreM, int posImg, String visor) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" "+UtilidadesGenerales.POSICION_MUESTRA+" "+"("+punto.x+","+punto.y+")");
    }
    
    private void registrarCargaLog(String nombreM, String visor) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", "+nombreM+" "+UtilidadesGenerales.CARGA_MUESTRA);
    }
    
    private void cargarImagenMuestraLog(String nombreM, int posImg,String visor, int w, int h) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" con las dimensiones "+w+"x"+h+" "+UtilidadesGenerales.CARGA_MUESTRA);
    }
    
    private void registrarZoomLog(String nombreM, int posImg, String visor,String scala) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" "+UtilidadesGenerales.ZOOM_MUESTRA+" "+scala);
    }
    
    private void registrarRedimension(String nombreM, int posImg, String visor, int w, int h){
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" "+UtilidadesGenerales.RED_MUESTRA+" "+w+"x"+h);
    }
    
    private void registrarGradoRotacion(String nombreM, int posImg,String visor,int grados){
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" se estableció a "+grados+" grados de rotación" );
    }
    
    private void registrarRotarImMuestraLog(String nombreM, int posImg,String visor, String orientacion,int rotacion) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" "+UtilidadesGenerales.GIRO_MUESTRA+" "+rotacion+" grados hacia "+orientacion);        
    }
    
    private void registrarVoltearImMuestraLog(String nombreM, int posImg,String visor,String orientacion) {
        String estampaTiempo = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
        log.add(estampaTiempo+", Visor "+visor+", La imagen "+posImg+" de "+nombreM+" "+UtilidadesGenerales.VOLT_MUESTRA+" "+orientacion);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VerMuestraX.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VerMuestraX.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VerMuestraX.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VerMuestraX.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VerMuestraX().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bloquearButton;
    private javax.swing.JTextField cajaGradosM1;
    private javax.swing.JTextField cajaGradosM2;
    private javax.swing.JTextField cajaTextoNroImagen;
    private javax.swing.JTextField cajaTextoNroImagen2;
    private javax.swing.JComboBox<String> comboMuestra;
    private javax.swing.JComboBox<String> comboMuestra2;
    private javax.swing.JButton guardarLogButton;
    private javax.swing.JLabel imagenMuestra;
    private javax.swing.JLabel imagenMuestra2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labelImagenes;
    private javax.swing.JLabel labelImagenes2;
    private javax.swing.JLabel labelMuestra;
    private javax.swing.JLabel labelMuestra2;
    private javax.swing.JLabel labelPosM1;
    private javax.swing.JLabel labelPosM2;
    private javax.swing.JLabel labelScaleM1;
    private javax.swing.JLabel labelScaleM2;
    private javax.swing.JButton modoDibujoButton;
    private javax.swing.JButton navImgDM1Button;
    private javax.swing.JButton navImgDM2Button;
    private javax.swing.JButton navImgIM1Button;
    private javax.swing.JButton navImgIM2Button;
    private javax.swing.JButton rotarDerM1Button;
    private javax.swing.JButton rotarDerM2Button;
    private javax.swing.JLabel rotarImgLabel;
    private javax.swing.JLabel rotarImgLabel2;
    private javax.swing.JButton rotarIzqM1Button;
    private javax.swing.JButton rotarIzqM2Button;
    private javax.swing.JSlider sliderM1;
    private javax.swing.JSlider sliderM2;
    private javax.swing.JButton voltearHorizM1Button;
    private javax.swing.JButton voltearHorizM2Button;
    private javax.swing.JLabel voltearImgLabel;
    private javax.swing.JLabel voltearImgLabel2;
    private javax.swing.JButton voltearVertM1Button;
    private javax.swing.JButton voltearVertM2Button;
    private javax.swing.JButton volverButton;
    // End of variables declaration//GEN-END:variables

}
